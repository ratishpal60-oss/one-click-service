exports.handler = async (event) => {
  try {
    const { message } = JSON.parse(event.body || "{}");

    if (!message) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          reply: "कृपया अपना प्रश्न लिखें।",
        }),
      };
    }

    const prompt = `
आप One Click Service के AI Assistant हैं.

सेवाएँ:
- Aadhaar Card
- PAN Card
- Voter ID
- Health Insurance
- Life Insurance
- Vehicle Insurance
- PF / EPF
- ESIC
- Scholarship
- Ticket Booking
- Government Services

उत्तर हमेशा सरल हिन्दी में दें।
यदि ग्राहक सेवा लेना चाहता है तो बताएं:

WhatsApp: 8077775175

प्रश्न:
${message}
`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: prompt,
                },
              ],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`Gemini API Error: ${response.status}`);
    }

    const data = await response.json();

    const reply =
      data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      "माफ़ कीजिए, अभी उत्तर उपलब्ध नहीं है।";

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ reply }),
    };
  } catch (error) {
    console.error("Error:", error);

    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        reply: "सर्वर में समस्या है। कृपया बाद में पुनः प्रयास करें।",
      }),
    };
  }
};